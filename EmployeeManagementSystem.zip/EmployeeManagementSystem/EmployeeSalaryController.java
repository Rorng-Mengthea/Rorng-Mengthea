import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.Scene;
import java.io.*;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

public class EmployeeSalaryController implements Initializable {

    @FXML
    private TableView<EmployeeSalary> table_view;
    @FXML
    private TableColumn<EmployeeSalary, Integer> column_employee_salary_employee;
    @FXML
    private TableColumn<EmployeeSalary, String> column_employee_salary_first_name;
    @FXML
    private TableColumn<EmployeeSalary, String> column_employee_salary_last_name;
    @FXML
    private TableColumn<EmployeeSalary, String> column_employee_salary_position;
    @FXML
    private TableColumn<EmployeeSalary, String> column_employee_salary_salary;

    @FXML
    private TextField textfield_employee_salary_id;
    @FXML
    private TextField textfield_employee_salary_first_name;
    @FXML
    private TextField textfield_employee_salary_last_name;
    @FXML
    private TextField textfield_employee_salary_position;
    @FXML
    private TextField textfield_employee_salary_salary;

    @FXML
    private Button button_employee_salary_clear;
    @FXML
    private Button button_employee_salary_update;
    @FXML
    private Button button_back_to_home;

    private ObservableList<EmployeeSalary> salaryList = FXCollections.observableArrayList();
    private ObservableList<Employee> employeeList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Initialize table columns
        column_employee_salary_employee.setCellValueFactory(new PropertyValueFactory<>("id"));
        column_employee_salary_first_name.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        column_employee_salary_last_name.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        column_employee_salary_position.setCellValueFactory(new PropertyValueFactory<>("position"));
        column_employee_salary_salary.setCellValueFactory(new PropertyValueFactory<>("salary"));

        // Load employee data
        loadEmployeeData();
        // Load salary data
        loadSalaryData();

        // Add listener to ID field to auto-fill other fields
        textfield_employee_salary_id.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.isEmpty()) {
                try {
                    int id = Integer.parseInt(newValue);
                    Employee employee = findEmployeeById(id);
                    if (employee != null) {
                        textfield_employee_salary_first_name.setText(employee.getFirstName());
                        textfield_employee_salary_last_name.setText(employee.getLastName());
                        textfield_employee_salary_position.setText(employee.getPosition());
                    }
                } catch (NumberFormatException e) {
                    // Ignore invalid input
                }
            }
        });

        // Add selection listener to table
        table_view.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                textfield_employee_salary_id.setText(String.valueOf(newSelection.getId()));
                textfield_employee_salary_first_name.setText(newSelection.getFirstName());
                textfield_employee_salary_last_name.setText(newSelection.getLastName());
                textfield_employee_salary_position.setText(newSelection.getPosition());
                textfield_employee_salary_salary.setText(newSelection.getSalary());
            }
        });
    }

    private Employee findEmployeeById(int id) {
        for (Employee employee : employeeList) {
            if (employee.getId() == id) {
                return employee;
            }
        }
        return null;
    }

    private void loadEmployeeData() {
        employeeList.clear();
        try {
            List<String> lines = Files.readAllLines(Paths.get("data_employee.csv"));
            int start = lines.size() > 0 && lines.get(0).startsWith("id,") ? 1 : 0;

            for (int i = start; i < lines.size(); i++) {
                String[] parts = lines.get(i).split(",");
                if (parts.length >= 7) {
                    Employee employee = new Employee(
                            Integer.parseInt(parts[0]), parts[1], parts[2],
                            parts[3], parts[4], parts[5], parts[6], "");
                    employeeList.add(employee);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadSalaryData() {
        salaryList.clear();
        try {
            // Create file if it doesn't exist
            File file = new File("employee_salaries.csv");
            if (!file.exists()) {
                file.createNewFile();
            }

            // First load all existing salary data
            List<String> lines = Files.readAllLines(Paths.get("employee_salaries.csv"));
            int start = lines.size() > 0 && lines.get(0).startsWith("id,") ? 1 : 0;

            // Create a map of existing salaries for quick lookup
            Map<Integer, String> existingSalaries = new HashMap<>();
            for (int i = start; i < lines.size(); i++) {
                String[] parts = lines.get(i).split(",");
                if (parts.length >= 2) {
                    existingSalaries.put(Integer.parseInt(parts[0]), parts[1]);
                }
            }

            // Now create salary entries for all employees
            for (Employee employee : employeeList) {
                String salary = existingSalaries.getOrDefault(employee.getId(), "0.00");
                EmployeeSalary empSalary = new EmployeeSalary(
                        employee.getId(),
                        employee.getFirstName(),
                        employee.getLastName(),
                        employee.getPosition(),
                        salary);
                salaryList.add(empSalary);
            }

            table_view.setItems(salaryList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void button_employee_salary_clear_action(ActionEvent event) {
        clearFields();
    }

    @FXML
    void button_employee_salary_update_action(ActionEvent event) {
        try {
            if (textfield_employee_salary_id.getText().isEmpty()) {
                showAlert("Error", "ID is required");
                return;
            }

            int id = Integer.parseInt(textfield_employee_salary_id.getText());
            String salary = textfield_employee_salary_salary.getText().isEmpty() ? "0.00"
                    : textfield_employee_salary_salary.getText();

            // Find and update the salary record
            boolean found = false;
            for (EmployeeSalary empSalary : salaryList) {
                if (empSalary.getId() == id) {
                    empSalary.setSalary(salary);
                    found = true;
                    break;
                }
            }

            if (!found) {
                Employee employee = findEmployeeById(id);
                if (employee != null) {
                    EmployeeSalary newSalary = new EmployeeSalary(
                            id,
                            employee.getFirstName(),
                            employee.getLastName(),
                            employee.getPosition(),
                            salary);
                    salaryList.add(newSalary);
                } else {
                    showAlert("Error", "Employee not found");
                    return;
                }
            }

            saveAllSalariesToFile();
            table_view.refresh();
            clearFields();

        } catch (NumberFormatException e) {
            showAlert("Invalid ID", "Employee ID must be a number");
        } catch (Exception e) {
            showAlert("Error", "Failed to save salary:\n" + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    void button_back_to_home_action(ActionEvent event) {
        try {
            Stage stage = (Stage) button_back_to_home.getScene().getWindow();
            Scene scene = FXMLLoader.load(getClass().getResource("HomeView.fxml"));
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveAllSalariesToFile() {
        try (PrintWriter out = new PrintWriter("employee_salaries.csv")) {
            out.println("id,salary");
            for (EmployeeSalary salary : salaryList) {
                // Only save if salary is not "0.00" (or save all)
                if (!"0.00".equals(salary.getSalary())) {
                    out.println(salary.getId() + "," + salary.getSalary());
                }
            }
        } catch (Exception e) {
            showAlert("Error", "Could not save salary data:\n" + e.getMessage());
        }
    }

    private void clearFields() {
        textfield_employee_salary_id.clear();
        textfield_employee_salary_first_name.clear();
        textfield_employee_salary_last_name.clear();
        textfield_employee_salary_position.clear();
        textfield_employee_salary_salary.clear();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}