import javafx.beans.property.*;

public class EmployeeSalary {
    private final IntegerProperty id;
    private final StringProperty firstName;
    private final StringProperty lastName;
    private final StringProperty position;
    private final StringProperty salary;

    public EmployeeSalary(int id, String firstName, String lastName, String position, String salary) {
        this.id = new SimpleIntegerProperty(id);
        this.firstName = new SimpleStringProperty(firstName);
        this.lastName = new SimpleStringProperty(lastName);
        this.position = new SimpleStringProperty(position);
        this.salary = new SimpleStringProperty(salary);
    }

    // Getters
    public int getId() {
        return id.get();
    }

    public String getFirstName() {
        return firstName.get();
    }

    public String getLastName() {
        return lastName.get();
    }

    public String getPosition() {
        return position.get();
    }

    public String getSalary() {
        return salary.get();
    }

    // Setters
    public void setSalary(String salary) {
        this.salary.set(salary);
    }

    // Property getters
    public IntegerProperty idProperty() {
        return id;
    }

    public StringProperty firstNameProperty() {
        return firstName;
    }

    public StringProperty lastNameProperty() {
        return lastName;
    }

    public StringProperty positionProperty() {
        return position;
    }

    public StringProperty salaryProperty() {
        return salary;
    }
}