
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    public static void main(String[] args) {
        launch(); // Launch the JavaFX application
    }

    @Override
    public void start(Stage stage) throws Exception {

        stage.setTitle("Employee Management System");
        stage.getIcons().add(new javafx.scene.image.Image(getClass().getResourceAsStream("icon.jpg")));
        Scene scene = FXMLLoader.load(getClass().getResource("LoginView.fxml"));
        

        stage.setScene(scene);
        stage.show();

    }
}