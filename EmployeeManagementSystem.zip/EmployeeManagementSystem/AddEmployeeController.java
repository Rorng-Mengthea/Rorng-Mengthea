
import javafx.event.ActionEvent;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import java.io.*;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.*;

import javafx.collections.*;
import javafx.fxml.*;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;

public class AddEmployeeController implements Initializable {

    @FXML
    private AnchorPane anchor_pane_import;

    @FXML
    private Button button_add;
    @FXML
    private Button button_clear;
    @FXML
    private Button button_delete;
    @FXML
    private Button button_home;
    @FXML
    private Button button_import;
    @FXML
    private Button button_update;

    @FXML
    private TableColumn<Employee, String> coloumn_first_name;
    @FXML
    private TableColumn<Employee, String> column_date_member;
    @FXML
    private TableColumn<Employee, String> column_gender;
    @FXML
    private TableColumn<Employee, Integer> column_id;
    @FXML
    private TableColumn<Employee, String> column_last_name;
    @FXML
    private TableColumn<Employee, String> column_phone;
    @FXML
    private TableColumn<Employee, String> column_position;

    @FXML
    private ComboBox<String> combo_box_gender;
    @FXML
    private ComboBox<String> combo_box_position;

    @FXML
    private TableView<Employee> table_view;

    @FXML
    private TextField textfield_first_name;
    @FXML
    private TextField textfield_id;
    @FXML
    private TextField textfield_last_name;
    @FXML
    private TextField textfield_phone;
    @FXML
    private TextField textfield_search;

    @FXML
    private ImageView imageView;
    private String imagePath = "";

    private ObservableList<Employee> employeeList = FXCollections.observableArrayList();

    @FXML
    void button_add_action(ActionEvent event) {
        try {
            if (textfield_id.getText().isEmpty() || textfield_first_name.getText().isEmpty()) {
                showAlert("Error", "ID and First Name are required");
                return;
            }

            int id = Integer.parseInt(textfield_id.getText());
            String firstName = textfield_first_name.getText();
            String lastName = textfield_last_name.getText();
            String phone = textfield_phone.getText();
            String position = combo_box_position.getValue();
            String gender = combo_box_gender.getValue();
            String dateMember = java.time.LocalDate.now().toString();

            System.out.println("Attempting to save: " +
                    id + "," + firstName + "," + lastName + "," + phone + "," +
                    position + "," + gender + "," + dateMember);

            String filePath = new File("./data_employee.csv").getAbsolutePath();
            System.out.println("Saving to: " + filePath);

            File file = new File("./data_employee.csv");
            boolean fileExists = file.exists();
            System.out.println("File exists: " + fileExists);

            try (FileWriter fw = new FileWriter(file, true);
                    BufferedWriter bw = new BufferedWriter(fw);
                    PrintWriter out = new PrintWriter(bw)) {

                if (!fileExists || file.length() == 0) {
                    out.println("id,firstName,lastName,phone,position,gender,dateMember");
                }

                out.println(id + "," + firstName + "," + lastName + "," +
                        phone + "," + position + "," + gender + "," +
                        dateMember + "," + imagePath);

                System.out.println("Data successfully written");
            }

            loadEmployeeData();
            clearFields();

        } catch (NumberFormatException e) {
            showAlert("Invalid ID", "Employee ID must be a number");
        } catch (Exception e) {
            showAlert("Error", "Failed to save employee:\n" + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    void button_clear_action(ActionEvent event) {
        clearFields();
    }

    private void clearFields() {
        textfield_id.clear();
        textfield_first_name.clear();
        textfield_last_name.clear();
        textfield_phone.clear();
        combo_box_position.setValue(null);
        combo_box_gender.setValue(null);
    }

    @FXML
    void button_delete_action(ActionEvent event) {
        Employee selectedEmployee = table_view.getSelectionModel().getSelectedItem();

        if (selectedEmployee != null) {
            employeeList.remove(selectedEmployee);
            saveAllEmployeesToFile();
        } else {
            showAlert("No Selection", "Please select an employee to delete");
        }
    }

    @FXML
    void button_home_action(ActionEvent event) {
        try {
            Stage stage = (Stage) button_home.getScene().getWindow();
            Scene scene = FXMLLoader.load(getClass().getResource("HomeView.fxml"));
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            // Optional: handle exception
        }
    }

    @FXML
    void button_import_action(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Select Employee Photo");
        fileChooser.getExtensionFilters().addAll(
                new ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"));

        File selectedFile = fileChooser.showOpenDialog(null);

        if (selectedFile != null) {
            try {
                File dir = new File("images");
                if (!dir.exists())
                    dir.mkdir();

                String newPath = "images/" + selectedFile.getName();
                Files.copy(selectedFile.toPath(),
                        new File(newPath).toPath(),
                        StandardCopyOption.REPLACE_EXISTING);

                imagePath = newPath;
                Image image = new Image(new File(imagePath).toURI().toString());
                imageView.setImage(image);

            } catch (Exception e) {
                showAlert("Error", "Failed to import image: " + e.getMessage());
            }
        }
    }

    @FXML
    void button_update_action(ActionEvent event) {
        Employee selectedEmployee = table_view.getSelectionModel().getSelectedItem();

        if (selectedEmployee != null) {
            try {
                selectedEmployee.setFirstName(textfield_first_name.getText());
                selectedEmployee.setLastName(textfield_last_name.getText());
                selectedEmployee.setPhone(textfield_phone.getText());
                selectedEmployee.setPosition(combo_box_position.getValue());
                selectedEmployee.setGender(combo_box_gender.getValue());

                saveAllEmployeesToFile();
                table_view.refresh();
                clearFields();

            } catch (Exception e) {
                showAlert("Error", "Could not update employee:\n" + e.getMessage());
            }
        } else {
            showAlert("No Selection", "Please select an employee to update");
        }
    }

    private void saveAllEmployeesToFile() {
        try (PrintWriter out = new PrintWriter("data_employee.csv")) {
            out.println("id,firstName,lastName,phone,position,gender,dateMember");
            for (Employee emp : employeeList) {
                out.println(emp.getId() + "," + emp.getFirstName() + "," +
                        emp.getLastName() + "," + emp.getPhone() + "," +
                        emp.getPosition() + "," + emp.getGender() + "," +
                        emp.getDateMember());
            }
        } catch (Exception e) {
            showAlert("Error", "Could not save data:\n" + e.getMessage());
        }
    }

    @FXML
    void combo_box_gender_action(ActionEvent event) {
    }

    @FXML
    void combo_box_position_action(ActionEvent event) {
    }

    @FXML
    void textfield_search_action(KeyEvent event) {
    }

    @FXML
    void handleSearch(KeyEvent event) {
        handleSearch();
    }

    void handleSearch() {
        String searchText = textfield_search.getText().toLowerCase().trim();

        if (searchText.isEmpty()) {
            table_view.setItems(employeeList);
            return;
        }

        ObservableList<Employee> filteredList = FXCollections.observableArrayList();

        for (Employee emp : employeeList) {
            // Check if any field contains the search text
            if (String.valueOf(emp.getId()).contains(searchText) ||
                    emp.getFirstName().toLowerCase().contains(searchText) ||
                    emp.getLastName().toLowerCase().contains(searchText) ||
                    emp.getPosition().toLowerCase().contains(searchText) ||
                    emp.getPhone().contains(searchText)) {
                filteredList.add(emp);
            }
        }

        table_view.setItems(filteredList);
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void loadEmployeeData() {
        employeeList.clear();
        try {
            List<String> lines = Files.readAllLines(Paths.get("data_employee.csv"));
            int start = lines.size() > 0 && lines.get(0).startsWith("id,") ? 1 : 0;

            for (int i = start; i < lines.size(); i++) {
                String[] parts = lines.get(i).split(",");
                if (parts.length >= 7) {
                    String imagePath = parts.length > 7 ? parts[7] : "";
                    Employee employee = new Employee(
                            Integer.parseInt(parts[0]), parts[1], parts[2],
                            parts[3], parts[4], parts[5], parts[6], imagePath);
                    employeeList.add(employee);
                }
            }
            table_view.setItems(employeeList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        combo_box_gender.getItems().addAll("Male", "Female", "Other");
        combo_box_position.getItems().addAll("Manager", "Developer", "Designer", "Tester", "HR");

        column_id.setCellValueFactory(cellData -> cellData.getValue().idProperty().asObject());
        coloumn_first_name.setCellValueFactory(cellData -> cellData.getValue().firstNameProperty());
        column_last_name.setCellValueFactory(cellData -> cellData.getValue().lastNameProperty());
        column_gender.setCellValueFactory(cellData -> cellData.getValue().genderProperty());
        column_phone.setCellValueFactory(cellData -> cellData.getValue().phoneProperty());
        column_position.setCellValueFactory(cellData -> cellData.getValue().positionProperty());
        column_date_member.setCellValueFactory(cellData -> cellData.getValue().dateMemberProperty());

        loadEmployeeData();

        table_view.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                textfield_id.setText(String.valueOf(newSelection.getId()));
                textfield_first_name.setText(newSelection.getFirstName());
                textfield_last_name.setText(newSelection.getLastName());
                textfield_phone.setText(newSelection.getPhone());
                combo_box_position.setValue(newSelection.getPosition());
                combo_box_gender.setValue(newSelection.getGender());

                if (newSelection.getImagePath() != null && !newSelection.getImagePath().isEmpty()) {
                    Image img = new Image(new File(newSelection.getImagePath()).toURI().toString());
                    imageView.setImage(img);
                } else {
                    imageView.setImage(null);
                }
            }
        });

        imageView.setFitHeight(140);
        imageView.setFitWidth(100);
        imageView.setPreserveRatio(true);

        textfield_search.textProperty().addListener((observable, oldValue, newValue) -> {
            handleSearch();
        });
    }
}
