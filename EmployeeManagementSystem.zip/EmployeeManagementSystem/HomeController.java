import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class HomeController {

    @FXML
    private BarChart<String, Number> bar_chart_employee_salary;

    @FXML
    private Button button_add_employee;

    @FXML
    private Button button_employee_salary;

    @FXML
    private Button button_logout;

    @FXML
    private Label label_total_employees;

    @FXML
    private Label label_total_inactive_employees;

    @FXML
    private Label label_total_presents;

    @FXML
    void initialize() {
        updateEmployeeCounts();
        updateBarChart();
    }

    private void updateEmployeeCounts() {
        try {
            // Load employee data
            List<String> employeeLines = Files.readAllLines(Paths.get("data_employee.csv"));
            int totalEmployees = employeeLines.size() - 1; // Subtract header

            // Load salary data
            Map<Integer, String> salaryMap = new HashMap<>();
            if (Files.exists(Paths.get("employee_salaries.csv"))) {
                List<String> salaryLines = Files.readAllLines(Paths.get("employee_salaries.csv"));
                for (int i = 1; i < salaryLines.size(); i++) { // Skip header
                    String[] parts = salaryLines.get(i).split(",");
                    if (parts.length >= 2) {
                        salaryMap.put(Integer.parseInt(parts[0]), parts[1]);
                    }
                }
            }

            // Count present and inactive employees
            int presentEmployees = 0;
            int inactiveEmployees = 0;

            for (int i = 1; i < employeeLines.size(); i++) {
                String[] parts = employeeLines.get(i).split(",");
                if (parts.length > 0) {
                    int id = Integer.parseInt(parts[0]);
                    String salary = salaryMap.getOrDefault(id, "0.00");

                    if (Double.parseDouble(salary) > 0) {
                        presentEmployees++;
                    } else {
                        inactiveEmployees++;
                    }
                }
            }

            // Update labels
            label_total_employees.setText(String.valueOf(totalEmployees));
            label_total_presents.setText(String.valueOf(presentEmployees));
            label_total_inactive_employees.setText(String.valueOf(inactiveEmployees));

        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Could not load employee data");
        }
    }

    private void updateBarChart() {
        bar_chart_employee_salary.getData().clear();

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Employee Salary Distribution");

        try {
            // Load salary data
            if (Files.exists(Paths.get("employee_salaries.csv"))) {
                List<String> salaryLines = Files.readAllLines(Paths.get("employee_salaries.csv"));

                // Count employees by salary range
                int range0 = 0; // 0
                int range1_1000 = 0; // 1-1000
                int range1001_2000 = 0; // 1001-2000
                int range2001_plus = 0; // 2001+

                for (int i = 1; i < salaryLines.size(); i++) { // Skip header
                    String[] parts = salaryLines.get(i).split(",");
                    if (parts.length >= 2) {
                        double salary = Double.parseDouble(parts[1]);

                        if (salary == 0) {
                            range0++;
                        } else if (salary <= 1000) {
                            range1_1000++;
                        } else if (salary <= 2000) {
                            range1001_2000++;
                        } else {
                            range2001_plus++;
                        }
                    }
                }

                // Add data to chart
                series.getData().add(new XYChart.Data<>("No Salary", range0));
                series.getData().add(new XYChart.Data<>("$1-$1000", range1_1000));
                series.getData().add(new XYChart.Data<>("$1001-$2000", range1001_2000));
                series.getData().add(new XYChart.Data<>("$2001+", range2001_plus));

                bar_chart_employee_salary.getData().add(series);
            }
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Could not load salary data for chart");
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    void button_add_employee_action(ActionEvent event) {
        try {
            Stage stage = (Stage) button_add_employee.getScene().getWindow();
            Scene scene = FXMLLoader.load(getClass().getResource("AddEmployeeView.fxml"));
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void button_employee_salary_action(ActionEvent event) {
        try {
            Stage stage = (Stage) button_employee_salary.getScene().getWindow();
            Scene scene = FXMLLoader.load(getClass().getResource("EmployeeSalary.fxml"));
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    void button_logout_action(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Logout");
        alert.setHeaderText("You have been logged out successfully.");
        alert.setContentText("Thank you for using the Employee Management System.");

        Optional<ButtonType> option = alert.showAndWait();
        if (option.get().equals(ButtonType.OK)) {
            try {
                Stage stage = (Stage) button_logout.getScene().getWindow();
                Scene scene = FXMLLoader.load(getClass().getResource("LoginView.fxml"));
                stage.setScene(scene);
                stage.show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}