
// Employee.java
import javafx.beans.property.*;

public class Employee {
    private final IntegerProperty id;
    private final StringProperty firstName;
    private final StringProperty lastName;
    private final StringProperty phone;
    private final StringProperty position;
    private final StringProperty gender;
    private final StringProperty dateMember;
    private final StringProperty imagePath;

    public Employee(int id, String firstName, String lastName, String phone,
            String position, String gender, String dateMember, String imagePath) {
        this.id = new SimpleIntegerProperty(id);
        this.firstName = new SimpleStringProperty(firstName);
        this.lastName = new SimpleStringProperty(lastName);
        this.phone = new SimpleStringProperty(phone);
        this.position = new SimpleStringProperty(position);
        this.gender = new SimpleStringProperty(gender);
        this.dateMember = new SimpleStringProperty(dateMember);
        this.imagePath = new SimpleStringProperty(imagePath);

    }

    // Getter methods
    public int getId() {
        return id.get();
    }

    public String getFirstName() {
        return firstName.get();
    }

    public String getLastName() {
        return lastName.get();
    }

    public String getPhone() {
        return phone.get();
    }

    public String getPosition() {
        return position.get();
    }

    public String getGender() {
        return gender.get();
    }

    public String getDateMember() {
        return dateMember.get();
    }

    // Setter methods
    public void setFirstName(String value) {
        firstName.set(value);
    }

    public void setLastName(String value) {
        lastName.set(value);
    }

    public void setPhone(String value) {
        phone.set(value);
    }

    public void setPosition(String value) {
        position.set(value);
    }

    public void setGender(String value) {
        gender.set(value);
    }

    // Property methods
    public IntegerProperty idProperty() {
        return id;
    }

    public StringProperty firstNameProperty() {
        return firstName;
    }

    public StringProperty lastNameProperty() {
        return lastName;
    }

    public StringProperty phoneProperty() {
        return phone;
    }

    public StringProperty positionProperty() {
        return position;
    }

    public StringProperty genderProperty() {
        return gender;
    }

    public StringProperty dateMemberProperty() {
        return dateMember;
    }

    public String getImagePath() {
        return imagePath.get();
    }

    public StringProperty imagePathProperty() {
        return imagePath;
    }
}
